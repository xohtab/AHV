# Discord Bot Host

A powerful and interactive Discord bot using Discord.js v14+ and Node.js that acts as a fully self-hosted bot launcher and file uploader — allowing users to upload, run, manage, and stop their own Discord bots directly inside Discord.

## Features

### Main Dashboard
- Dynamic embed with 3 primary buttons:
  1. 🔼 Upload Bot
  2. 🧾 My Bots
  3. ⚙️ Admin Panel
- Real-time stats:
  - 🤖 Bots Running
  - 👥 Users Hosting Bots
  - 🔁 Total Restarts
  - 🛑 Crashed Bots

### Upload Bot Feature
- Modal to input Bot Name and Bot Token
- DM to upload .zip or .js file
- Validation of file structure
- Extraction and saving of files locally
- Running the bot in a forked process
- Confirmation embed with status

### My Bots Feature
- Lists all bots uploaded by the user
- Shows status, uptime, file size
- Buttons to stop, restart, delete, and view logs

### Admin Panel
- Admin-only access
- Overview of all bots running
- Bot owners and system resource usage
- Force restart, shutdown, and ban user options

### Security Features
- Tier-based limits (Free: 1 bot, Premium: 5 bots, Ultimate: 10 bots)
- Token encryption before storage
- Forbidden keywords protection

## Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/discord-bot-host.git
cd discord-bot-host
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file with the following variables:
```
TOKEN=your_discord_bot_token_here
MONGODB_URI=your_mongodb_connection_string_here
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here
ADMIN_ROLE_ID=your_admin_role_id_here
```

4. Register slash commands:
```bash
node deploy-commands.js
```

5. Start the bot:
```bash
node index.js
```

## Required Permissions

The bot requires the following permissions:
- Read Messages/View Channels
- Send Messages
- Embed Links
- Attach Files
- Read Message History
- Use External Emojis
- Add Reactions
- Use Slash Commands

## Bot Commands

- `/dashboard` - Creates or updates the bot host dashboard
- `/uploadbot` - Upload a new Discord bot to the host
- `/startbot <botid>` - Start one of your bots
- `/stopbot <botid>` - Stop one of your bots
- `/restartbot <botid>` - Restart one of your bots

## Technical Details

- Built using Discord.js v14+
- Uses child_process.fork for isolated bot processes
- MongoDB for database storage
- Crypto-js for token encryption
- File management with fs-extra and adm-zip

## License

MIT

## Author
Enzo
جميع الحقوق محفوظة لو حاولت تبيعه أنت غبي
