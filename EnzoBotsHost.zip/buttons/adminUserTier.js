const { EmbedBuilder } = require('discord.js');
const User = require('../database/models/User');

module.exports = {
  customId: 'adminUserTier',
  
  async execute(interaction, client) {
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Parse customId to get tier and userId
      const parts = interaction.customId.split(':');
      const tierName = parts[1]; // premium, ultimate, or free
      const userId = parts[2];
      
      // Check if user has admin role
      const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
      const isAdmin = adminRoleIds.some(roleId => interaction.member.roles.cache.has(roleId));
      
      if (!isAdmin) {
        return interaction.editReply({
          content: 'ليس لديك صلاحيات للوصول إلى لوحة الإدارة.',
          ephemeral: true
        });
      }
      
      // Find user in database
      const user = await User.findOne({ userId });
      
      if (!user) {
        return interaction.editReply({
          content: 'لم يتم العثور على المستخدم.',
          ephemeral: true
        });
      }
      
      // Get tier display name in Arabic
      const tierDisplayName = {
        free: 'مجاني',
        premium: 'بريميوم',
        ultimate: 'ألتميت'
      }[tierName];
      
      // Update user tier
      const oldTier = user.tier;
      user.tier = tierName;
      await user.save();
      
      // Reply to user
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('🔰 تم تحديث الخطة')
            .setDescription(`تم تحديث خطة المستخدم **${user.username}** من **${oldTier}** إلى **${tierName}** (${tierDisplayName}).`)
            .setColor(tierName === 'premium' ? '#9b59b6' : tierName === 'ultimate' ? '#f1c40f' : '#95a5a6')
            .setTimestamp()
        ],
        ephemeral: true
      });
      
      // Notify the user about tier change
      const targetUser = await interaction.client.users.fetch(userId).catch(() => null);
      if (targetUser) {
        targetUser.createDM().then(dmChannel => {
          dmChannel.send({
            embeds: [
              new EmbedBuilder()
                .setTitle('🔰 تم تحديث خطتك')
                .setDescription(`تم تحديث خطتك من **${oldTier}** إلى **${tierName}** (${tierDisplayName}) بواسطة المسؤول.`)
                .setColor(tierName === 'premium' ? '#9b59b6' : tierName === 'ultimate' ? '#f1c40f' : '#95a5a6')
                .setTimestamp()
            ]
          });
        }).catch(err => console.error('Failed to send DM to user:', err));
      }
    } catch (error) {
      console.error(`Error handling admin user tier (${interaction.customId}):`, error);
      
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: 'حدث خطأ أثناء تحديث خطة المستخدم. يرجى المحاولة مرة أخرى.',
          ephemeral: true
        });
      } else {
        await interaction.editReply({
          content: 'حدث خطأ أثناء تحديث خطة المستخدم. يرجى المحاولة مرة أخرى.',
          ephemeral: true
        });
      }
    }
  }
}; 