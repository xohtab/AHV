const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Bot = require('../database/models/Bot');
const User = require('../database/models/User');
const osu = require('node-os-utils');

module.exports = {
  customId: 'adminPanel',
  
  async execute(interaction, client) {
    try {
      // Check if user has admin role
      const adminRoleId = process.env.ADMIN_ROLE_ID;
      const isAdmin = interaction.member.roles.cache.has(adminRoleId);
      
      if (!isAdmin) {
        return interaction.reply({
          content: 'You do not have permission to access the admin panel.',
          ephemeral: true
        });
      }
      
      await interaction.deferReply({ ephemeral: true });
      
      // Get system stats
      const cpu = await osu.cpu.usage();
      const mem = await osu.mem.info();
      const uptime = formatUptime(client.uptime);
      
      // Get all bots from database
      const allBots = await Bot.find({}).sort({ createdAt: -1 });
      const runningBots = [...client.runningBots.values()];
      
      // Get all users
      const allUsers = await User.find({});
      const bannedUsers = allUsers.filter(user => user.isBanned).length;
      
      // Create admin dashboard embed
      const embed = new EmbedBuilder()
        .setTitle('⚙️ Admin Panel')
        .setDescription('Manage all bots and users on the platform')
        .addFields(
          { name: '🤖 Total Bots', value: allBots.length.toString(), inline: true },
          { name: '🟢 Running Bots', value: runningBots.length.toString(), inline: true },
          { name: '👥 Total Users', value: allUsers.length.toString(), inline: true },
          { name: '🚫 Banned Users', value: bannedUsers.toString(), inline: true },
          { name: '💻 CPU Usage', value: `${cpu.toFixed(1)}%`, inline: true },
          { name: '🧠 Memory Usage', value: `${mem.usedMemPercentage.toFixed(1)}%`, inline: true },
          { name: '⏱️ Bot Uptime', value: uptime, inline: true }
        )
        .setColor('#9b59b6')
        .setTimestamp();
      
      // Create action buttons
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('adminAction:viewBots')
            .setLabel('View All Bots')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('adminAction:viewUsers')
            .setLabel('Manage Users')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('adminAction:systemStats')
            .setLabel('System Stats')
            .setStyle(ButtonStyle.Secondary)
        );
      
      await interaction.editReply({
        embeds: [embed],
        components: [row],
        ephemeral: true
      });
    } catch (error) {
      console.error('Error handling admin panel button:', error);
      await interaction.reply({
        content: 'An error occurred while loading the admin panel. Please try again.',
        ephemeral: true
      });
    }
  }
};

// Helper function to format uptime
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days}d ${hours % 24}h ${minutes % 60}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
}
