const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const User = require('../database/models/User');
const Bot = require('../database/models/Bot');

module.exports = {
  customId: 'uploadBot',
  
  async execute(interaction, client) {
    try {
      // Check if user exists in database, if not create them
      let user = await User.findOne({ userId: interaction.user.id });
      
      if (!user) {
        user = await User.create({
          userId: interaction.user.id,
          username: interaction.user.tag,
          tier: 'free',
          isBanned: false,
          createdAt: Date.now(),
          lastActive: Date.now()
        });
      } else {
        // Update user's last active time
        user.lastActive = Date.now();
        
        // Update user's tag if it has changed
        if (user.username !== interaction.user.tag) {
          user.username = interaction.user.tag;
        }
        
        // Check if the user's tier should be updated based on roles
        const roleTier = await getUserTierFromRoles(interaction.user.id, interaction.guild.id);
        if (roleTier && roleTier !== user.tier) {
          user.tier = roleTier;
        }
        
        await user.save();
      }
      
      // Check if user is banned
      if (user.isBanned) {
        return interaction.reply({
          content: `تم حظرك من استخدام هذه الخدمة. السبب: ${user.banReason || 'غير محدد'}`,
          ephemeral: true
        });
      }
      
      // Get user's current bots
      const userBots = await Bot.find({ owner: interaction.user.id });
      
      // Check if user has reached their bot limit
      const userTier = user ? user.tier : 'free';
      const botLimit = getBotLimit(userTier);
      
      if (userBots.length >= botLimit) {
        return interaction.reply({
          content: `لقد وصلت إلى الحد الأقصى لعدد البوتات المسموح بها (${botLimit}). قم بترقية خطتك للحصول على المزيد من البوتات.`,
          ephemeral: true
        });
      }
      
      // Generate a default bot name
      const botName = `Bot-${Date.now()}`;
      
      // Store user's upload request with default values
      client.userBotUploads.set(interaction.user.id, {
        botName,
        timestamp: Date.now()
      });
      
      // Simply ask for file upload directly
      await interaction.reply({ 
        content: 'يرجى التحقق من الرسائل الخاصة بك لرفع ملف البوت.',
        flags: 64 // Using flags: 64 instead of ephemeral: true
      });
      
      try {
        const dmChannel = await interaction.user.createDM();
        await dmChannel.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('🔼 رفع البوت')
              .setDescription(`يرجى رفع ملف البوت الخاص بك.\nالصيغ المقبولة: \`.zip\` أو \`.js\`\nسيتم استخراج الملف وتشغيله تلقائيًا.`)
              .setColor('#3498db')
              .setFooter({ text: 'ستنتهي صلاحية طلب الرفع في غضون 5 دقائق' })
          ]
        });
        
        // Set a timeout to clear the upload request after 5 minutes
        setTimeout(() => {
          if (client.userBotUploads.has(interaction.user.id)) {
            client.userBotUploads.delete(interaction.user.id);
            dmChannel.send('انتهت صلاحية طلب رفع البوت. يرجى المحاولة مرة أخرى.');
          }
        }, 5 * 60 * 1000);
      } catch (error) {
        console.error('Failed to send DM:', error);
        await interaction.followUp({ 
          content: 'لم أتمكن من إرسال رسالة خاصة إليك. يرجى التأكد من أن الرسائل الخاصة مفتوحة.',
          ephemeral: true 
        });
        client.userBotUploads.delete(interaction.user.id);
      }
    } catch (error) {
      console.error('Error handling upload bot button:', error);
      // Check if we can reply to the interaction
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
          ephemeral: true
        }).catch(err => console.error('Could not send error reply:', err));
      }
    }
  }
};

// Helper function to get bot limit based on tier
function getBotLimit(tier) {
  switch (tier) {
    case 'premium':
      return 5;
    case 'ultimate':
      return 10;
    case 'free':
    default:
      return 1;
  }
}

// Helper function to check user tier based on roles
async function getUserTierFromRoles(userId, guildId) {
  try {
    // Check if the necessary role IDs are configured
    const premiumRoleId = process.env.PREMIUM_ROLE_ID;
    const ultimateRoleId = process.env.ULTIMATE_ROLE_ID;

    if (!premiumRoleId && !ultimateRoleId) {
      return null; // No roles configured, can't determine tier from roles
    }
    
    // Get the guild
    const guild = global.discordClient.guilds.cache.get(guildId || process.env.GUILD_ID);
    if (!guild) return null;

    // Get the member
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return null;

    // Check roles from highest to lowest
    if (ultimateRoleId && member.roles.cache.has(ultimateRoleId)) {
      return 'ultimate';
    } else if (premiumRoleId && member.roles.cache.has(premiumRoleId)) {
      return 'premium';
    }

    return 'free';
  } catch (error) {
    console.error(`Error getting user tier from roles: ${error.message}`);
    return null;
  }
}
