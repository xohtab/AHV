const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Bot = require('../database/models/Bot');
const User = require('../database/models/User');
const fs = require('fs-extra');
const moment = require('moment');
const path = require('path');

module.exports = {
  customId: 'myBots',
  
  async execute(interaction, client) {
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Check if user exists in database, if not create them
      let user = await User.findOne({ userId: interaction.user.id });
      
      if (!user) {
        user = await User.create({
          userId: interaction.user.id,
          username: interaction.user.tag,
          tier: 'free',
          isBanned: false,
          createdAt: Date.now(),
          lastActive: Date.now()
        });
      } else {
        // Update user's last active time
        user.lastActive = Date.now();
        
        // Update user's tag if it has changed
        if (user.username !== interaction.user.tag) {
          user.username = interaction.user.tag;
        }
        
        // Check if the user's tier should be updated based on roles
        const roleTier = await getUserTierFromRoles(interaction.user.id, interaction.guild.id);
        if (roleTier && roleTier !== user.tier) {
          user.tier = roleTier;
        }
        
        await user.save();
      }
      
      // Check if user is banned
      if (user.isBanned) {
        return interaction.editReply({
          content: `تم حظرك من استخدام هذه الخدمة. السبب: ${user.banReason || 'غير محدد'}`,
          ephemeral: true
        });
      }
      
      // Get user's bots from database
      const userBots = await Bot.find({ owner: interaction.user.id });
      
      if (userBots.length === 0) {
        return interaction.editReply({
          content: 'ليس لديك أي بوتات حتى الآن. استخدم زر "رفع بوت" لإنشاء واحد!',
          ephemeral: true
        });
      }
      
      // Create embeds for each bot
      const embeds = [];
      const components = [];
      
      for (const bot of userBots) {
        // Check if bot is actually running
        const runningBot = client.botProcesses.get(bot.name);
        const isRunning = runningBot !== undefined;
        
        // Calculate uptime
        let uptime = 'Not running';
        if (isRunning) {
          const uptimeMs = Date.now() - runningBot.startTime;
          uptime = formatUptime(uptimeMs);
        }
        
        // Get file size
        let fileSize = 'Unknown';
        try {
          if (fs.existsSync(bot.path)) {
            fileSize = formatBytes(getDirectorySize(bot.path));
          } else {
            fileSize = 'Directory not found';
          }
        } catch (error) {
          console.error(`Error getting file size for bot ${bot.name}:`, error);
        }
        
        // Create embed
        const embed = new EmbedBuilder()
          .setTitle(`🤖 ${bot.name}`)
          .setDescription(`**الحالة**: ${isRunning ? '🟢 قيد التشغيل' : '🔴 متوقف'}`)
          .addFields(
            { name: '📁 اسم البوت', value: bot.name, inline: true },
            { name: '🕒 وقت التشغيل', value: uptime, inline: true },
            { name: '💾 الحجم', value: fileSize, inline: true },
            { name: '🔁 إعادة التشغيل', value: bot.restarts.toString(), inline: true },
            { name: '📅 تاريخ الإنشاء', value: moment(bot.createdAt).format('YYYY-MM-DD HH:mm'), inline: true }
          )
          .setColor(isRunning ? '#2ecc71' : '#e74c3c')
          .setFooter({ text: `معرف البوت: ${bot.botId}` });
        
        embeds.push(embed);
        
        // Create action buttons for this bot
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`botAction:${isRunning ? 'stop' : 'start'}:${bot.name}`)
              .setLabel(isRunning ? '⏹️ إيقاف' : '▶️ تشغيل')
              .setStyle(isRunning ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId(`botAction:restart:${bot.name}`)
              .setLabel('🔄 إعادة تشغيل')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(!isRunning),
            new ButtonBuilder()
              .setCustomId(`botAction:delete:${bot.name}`)
              .setLabel('🗑️ حذف')
              .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
              .setCustomId(`botAction:logs:${bot.name}`)
              .setLabel('📄 السجلات')
              .setStyle(ButtonStyle.Secondary)
          );
        
        components.push(row);
      }
      
      // Send embeds and components
      await interaction.editReply({
        content: `لديك ${userBots.length} بوت/بوتات:`,
        embeds: embeds,
        components: components,
        ephemeral: true
      });
    } catch (error) {
      console.error('Error handling my bots button:', error);
      await interaction.editReply({
        content: 'حدث خطأ أثناء جلب البوتات الخاصة بك. يرجى المحاولة مرة أخرى.',
        ephemeral: true
      });
    }
  }
};

// Helper function to format uptime
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days}d ${hours % 24}h`;
  } else if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
}

// Helper function to format bytes
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Helper function to get directory size
function getDirectorySize(directoryPath) {
  let totalSize = 0;
  
  try {
    // Check if directory exists
    if (!fs.existsSync(directoryPath)) {
      console.error(`Directory does not exist: ${directoryPath}`);
      return 0;
    }
    
    const files = fs.readdirSync(directoryPath);
    
    for (const file of files) {
      try {
        const filePath = path.join(directoryPath, file);
        const stats = fs.statSync(filePath);
        
        if (stats.isDirectory()) {
          totalSize += getDirectorySize(filePath);
        } else {
          totalSize += stats.size;
        }
      } catch (fileError) {
        console.error(`Error with file ${file} in ${directoryPath}:`, fileError);
        // Continue with next file
      }
    }
  } catch (error) {
    console.error(`Error calculating directory size for ${directoryPath}:`, error);
  }
  
  return totalSize;
}

// Helper function to check user tier based on roles
async function getUserTierFromRoles(userId, guildId) {
  try {
    // Check if the necessary role IDs are configured
    const premiumRoleId = process.env.PREMIUM_ROLE_ID;
    const ultimateRoleId = process.env.ULTIMATE_ROLE_ID;

    if (!premiumRoleId && !ultimateRoleId) {
      return null; // No roles configured, can't determine tier from roles
    }

    // Get client from global access or pass it as parameter
    const Discord = require('discord.js');
    if (!global.discordClient) {
      return null;
    }
    
    // Get the guild
    const guild = global.discordClient.guilds.cache.get(guildId || process.env.GUILD_ID);
    if (!guild) return null;

    // Get the member
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return null;

    // Check roles from highest to lowest
    if (ultimateRoleId && member.roles.cache.has(ultimateRoleId)) {
      return 'ultimate';
    } else if (premiumRoleId && member.roles.cache.has(premiumRoleId)) {
      return 'premium';
    }

    return 'free';
  } catch (error) {
    console.error(`Error getting user tier from roles: ${error.message}`);
    return null;
  }
}
