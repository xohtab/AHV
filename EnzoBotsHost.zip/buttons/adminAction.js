const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const Bot = require('../database/models/Bot');
const User = require('../database/models/User');
const osu = require('node-os-utils');
const fs = require('fs-extra');
const path = require('path');
const { sendLogToChannel, logBotDeletion, logUserDeletion, logBotRestart, logBotShutdown } = require('../utils/logUtils');

module.exports = {
  customId: 'adminAction',
  
  async execute(interaction, client) {
    try {
      // Parse customId to get action and parameters
      const parts = interaction.customId.split(':');
      const action = parts[1];
      const param1 = parts[2]; // botId, userId or other parameter
      const param2 = parts[3]; // index for uniqueness or other purpose
      
      // Check if user has admin role
      const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
      const isAdmin = adminRoleIds.some(roleId => interaction.member.roles.cache.has(roleId));
      
      if (!isAdmin) {
        await interaction.reply({
          content: 'ليس لديك صلاحيات للوصول إلى لوحة الإدارة.',
          ephemeral: true
        });
        return;
      }
      
      // For 'banUser' action, we need to show the modal BEFORE deferring/replying
      if (action === 'banUser') {
        // Extract the userId from the parts
        const userId = parts[2];
        await showBanUserModal(interaction, userId);
        return;
      }
      
      // For 'giveRole' action, we also need to show the modal before deferring
      if (action === 'giveRole') {
        const userId = parts[2];
        await showGiveRoleModal(interaction, userId);
        return;
      }
      
      // For all other actions, defer the reply
      await interaction.deferReply({ ephemeral: true });
      
      // Handle different actions
      switch (action) {
        case 'viewBots':
          await viewAllBots(interaction, client);
          break;
        case 'viewUsers':
          await viewAllUsers(interaction, client);
          break;
        case 'systemStats':
          await viewSystemStats(interaction, client);
          break;
        case 'forceRestart':
          await forceRestartBot(interaction, client, param1);
          break;
        case 'shutdownBot':
          await shutdownBot(interaction, client, param1);
          break;
        case 'unbanUser':
          await unbanUser(interaction, param1);
          break;
        case 'deleteBot':
          await deleteBot(interaction, client, param1);
          break;
        case 'deleteUser':
          await deleteUser(interaction, client, param1);
          break;
        case 'giveRole':
          // This is now handled before deferring
          break;
        default:
          await interaction.editReply({
            content: 'إجراء غير صالح.',
            ephemeral: true
          });
      }
    } catch (error) {
      console.error(`Error handling admin action (${interaction.customId}):`, error);
      
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
          ephemeral: true
        });
      } else {
      await interaction.editReply({
          content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
        ephemeral: true
      });
      }
    }
  }
};

// Function to view all bots
async function viewAllBots(interaction, client) {
  try {
    // Get all bots from database
    const allBots = await Bot.find({}).sort({ createdAt: -1 });
    
    if (allBots.length === 0) {
      return interaction.editReply({
        content: 'لا يوجد بوتات في النظام.',
        ephemeral: true
      });
    }
    
    // Create embeds for bots (paginate if needed)
    const botsPerPage = 10;
    const totalPages = Math.ceil(allBots.length / botsPerPage);
    const currentPage = 1;
    
    const startIndex = (currentPage - 1) * botsPerPage;
    const endIndex = Math.min(startIndex + botsPerPage, allBots.length);
    const currentBots = allBots.slice(startIndex, endIndex);
    
    // Create embed
    const embed = new EmbedBuilder()
      .setTitle('🤖 جميع البوتات')
      .setDescription(`عرض ${startIndex + 1}-${endIndex} من ${allBots.length} بوت`)
      .setColor('#3498db')
      .setFooter({ text: `صفحة ${currentPage}/${totalPages}` });
    
    // Add fields for each bot
    for (const bot of currentBots) {
      const isRunning = client.runningBots.has(bot.botId);
      const owner = await interaction.client.users.fetch(bot.owner).catch(() => null);
      const ownerName = owner ? owner.tag : 'Unknown';
      
      embed.addFields({
        name: `${isRunning ? '🟢' : '🔴'} ${bot.name}`,
        value: `**المالك:** ${ownerName}\n**المعرف:** ${bot.botId}\n**تاريخ الإنشاء:** <t:${Math.floor(bot.createdAt.getTime() / 1000)}:R>\n**عدد مرات التشغيل:** ${bot.restarts}`,
        inline: false
      });
    }
    
    // Create action buttons for navigation and actions
    const components = [];
    
    // Add navigation buttons
    const navigationRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`adminBotPage:prev:${currentPage}:${Date.now()}`)
          .setLabel('◀️ السابق')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(currentPage === 1),
        new ButtonBuilder()
          .setCustomId(`adminBotPage:next:${currentPage}:${Date.now()}`)
          .setLabel('التالي ▶️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(currentPage === totalPages),
        new ButtonBuilder()
          .setCustomId(`adminAction:viewBots:${Date.now()}:refresh`)
          .setLabel('🔄 تحديث')
          .setStyle(ButtonStyle.Primary)
      );
    
    components.push(navigationRow);
    
    // Discord only allows max 5 action rows per message
    // We need to limit the number of bot action rows we add
    const maxBotRows = 4; // Max number of bot action rows (navigation row already added)
    const botsToShow = currentBots.slice(0, maxBotRows);
    
    // Add action buttons for each bot
    for (let i = 0; i < botsToShow.length; i++) {
      const bot = botsToShow[i];
      const isRunning = client.runningBots.has(bot.botId);
      
      const actionRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`botAction:${isRunning ? 'stop' : 'start'}:${bot.botId}:${i}`)
            .setLabel(isRunning ? '⛔ إيقاف' : '▶️ تشغيل')
            .setStyle(isRunning ? ButtonStyle.Danger : ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`botAction:restart:${bot.botId}:${i}`)
            .setLabel('🔄 إعادة تشغيل')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(!isRunning),
          new ButtonBuilder()
            .setCustomId(`botAction:logs:${bot.botId}:${i}`)
            .setLabel('📝 السجلات')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId(`adminAction:deleteBot:${bot.botId}:${i}`)
            .setLabel('🗑️ حذف')
            .setStyle(ButtonStyle.Danger)
        );
      
      components.push(actionRow);
    }
    
    // If there are more bots than we can show action rows for
    if (currentBots.length > maxBotRows) {
      embed.setDescription(`عرض ${startIndex + 1}-${startIndex + maxBotRows} من ${allBots.length} بوت (قيود ديسكورد تحد من عدد الأزرار المعروضة)`);
    }
    
    await interaction.editReply({
      embeds: [embed],
      components: components,
      ephemeral: true
    });
  } catch (error) {
    console.error('Error viewing all bots:', error);
    await interaction.editReply({
      content: 'حدث خطأ أثناء جلب البوتات. يرجى المحاولة مرة أخرى.',
      ephemeral: true
    });
  }
}

// Function to view all users
async function viewAllUsers(interaction, client) {
  try {
    // Get all users from database
    const allUsers = await User.find({}).sort({ createdAt: -1 });
    
    // Filter out users with missing or invalid userIds
    const validUsers = allUsers.filter(user => user && user.userId);
    
    if (validUsers.length === 0) {
      return interaction.editReply({
        content: 'لا يوجد مستخدمين في النظام.',
        ephemeral: true
      });
    }
    
    // Create embeds for users (paginate if needed)
    const usersPerPage = 10;
    const totalPages = Math.ceil(validUsers.length / usersPerPage);
    const currentPage = 1;
    
    const startIndex = (currentPage - 1) * usersPerPage;
    const endIndex = Math.min(startIndex + usersPerPage, validUsers.length);
    const currentUsers = validUsers.slice(startIndex, endIndex);
    
    // Create embed
    const embed = new EmbedBuilder()
      .setTitle('👥 جميع المستخدمين')
      .setDescription(`عرض ${startIndex + 1}-${endIndex} من ${validUsers.length} مستخدم`)
      .setColor('#3498db')
      .setFooter({ text: `صفحة ${currentPage}/${totalPages}` });
    
    // Add fields for each user
    for (const user of currentUsers) {
      const userBots = await Bot.countDocuments({ owner: user.userId });
      const userRunningBots = [...client.runningBots.values()].filter(bot => bot.owner === user.userId).length;
      
      embed.addFields({
        name: `${user.isBanned ? '🚫' : '👤'} ${user.username}`,
        value: `**المعرف:** ${user.userId}\n**الخطة:** ${user.tier === 'free' ? 'مجانية' : user.tier === 'premium' ? 'بريميوم' : 'ألتميت'}\n**البوتات:** ${userBots} (${userRunningBots} نشط)\n**آخر نشاط:** <t:${Math.floor(user.lastActive.getTime() / 1000)}:R>\n${user.isBanned ? `**سبب الحظر:** ${user.banReason || 'لم يتم تحديد سبب'}` : ''}`,
        inline: false
      });
    }
    
    // Create action buttons for navigation and actions
    const components = [];
    
    // Add navigation buttons
    const navigationRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`adminUserPage:prev:${currentPage}:${Date.now()}`)
          .setLabel('◀️ السابق')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(currentPage === 1),
        new ButtonBuilder()
          .setCustomId(`adminUserPage:next:${currentPage}:${Date.now()}`)
          .setLabel('التالي ▶️')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(currentPage === totalPages),
        new ButtonBuilder()
          .setCustomId(`adminAction:viewUsers:${Date.now()}:refresh`)
          .setLabel('🔄 تحديث')
          .setStyle(ButtonStyle.Primary)
      );
    
    components.push(navigationRow);
    
    // Discord only allows max 5 action rows per message
    // We need to limit the number of user action rows we add
    const maxUserRows = 4; // Max number of user action rows (navigation row already added)
    const usersToShow = currentUsers.slice(0, maxUserRows);
    
    // Add action buttons for each user
    for (let i = 0; i < usersToShow.length; i++) {
      const user = usersToShow[i];
      
      // Skip users with undefined or missing userId
      if (!user || !user.userId) {
        console.error(`Skipping user with invalid userId at index ${i}:`, user);
        continue;
      }
      
      const actionRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`adminAction:${user.isBanned ? 'unbanUser' : 'banUser'}:${user.userId}:${i}`) // Add index for uniqueness
            .setLabel(user.isBanned ? '✅ إلغاء الحظر' : '🚫 حظر المستخدم')
            .setStyle(user.isBanned ? ButtonStyle.Success : ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`adminAction:giveRole:${user.userId}:${i}`) // Use role-based tier
            .setLabel('➕ تعيين الرتبة')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(`adminAction:deleteUser:${user.userId}:${i}`) // Add delete user button
            .setLabel('❌ حذف المستخدم')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`adminUserBots:view:${user.userId}:${i}`) // View user's bots
            .setLabel('🤖 عرض البوتات')
            .setStyle(ButtonStyle.Secondary)
        );
      
      components.push(actionRow);
    }
    
    // If there are more users than we can show action rows for
    if (currentUsers.length > maxUserRows) {
      embed.setDescription(`عرض ${startIndex + 1}-${startIndex + maxUserRows} من ${validUsers.length} مستخدم (قيود ديسكورد تحد من عدد الأزرار المعروضة)`);
    }
    
    await interaction.editReply({
      embeds: [embed],
      components: components,
      ephemeral: true
    });
  } catch (error) {
    console.error('Error viewing all users:', error);
    await interaction.editReply({
      content: 'حدث خطأ أثناء جلب المستخدمين. يرجى المحاولة مرة أخرى.',
      ephemeral: true
    });
  }
}

// Function to view system stats
async function viewSystemStats(interaction, client) {
  try {
    // Get CPU stats
    const cpu = osu.cpu;
    const cpuUsage = await cpu.usage();
    const cpuCount = cpu.count();
    
    // Get memory stats
    const mem = osu.mem;
    const memInfo = await mem.info();
    
    // Get disk stats
    const diskInfo = await getDiskInfo();
    
    // Get uptime
    const uptime = process.uptime();
    
    // Create embed
    const embed = new EmbedBuilder()
      .setTitle('⚙️ إحصائيات النظام')
      .setColor('#3498db')
      .addFields(
        { name: '🖥️ المعالج', value: `استخدام: ${cpuUsage.toFixed(2)}%\nعدد النوى: ${cpuCount}`, inline: true },
        { name: '💾 الذاكرة', value: `المستخدمة: ${formatBytes(memInfo.usedMemMb * 1024 * 1024)}\nالإجمالية: ${formatBytes(memInfo.totalMemMb * 1024 * 1024)}\nاستخدام: ${(memInfo.usedMemMb / memInfo.totalMemMb * 100).toFixed(2)}%`, inline: true },
        { name: '💿 القرص', value: `المستخدم: ${formatBytes(diskInfo.used)}\nالإجمالي: ${formatBytes(diskInfo.total)}\nاستخدام: ${diskInfo.usedPercentage}%`, inline: true },
        { name: '⏰ زمن التشغيل', value: formatUptime(uptime * 1000), inline: true },
        { name: '👾 Node.js', value: process.version, inline: true },
        { name: '🤖 إحصائيات البوت', value: `البوتات النشطة: ${client.botStats.botsRunning}\nالمستخدمين: ${client.botStats.usersHosting}\nإعادة التشغيل: ${client.botStats.totalRestarts}\nالبوتات المتعطلة: ${client.botStats.crashedBots}`, inline: true }
      )
      .setFooter({ text: `آخر تحديث: ${new Date().toLocaleString()}` });
    
    // Create action buttons for system stats
    const actionRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('adminAction:systemStats:refresh:0')
          .setLabel('🔄 تحديث الإحصائيات')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('adminAction:viewBots:stats:1') // Add suffix to make it unique
          .setLabel('🤖 عرض البوتات')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('adminAction:viewUsers:stats:2') // Add suffix to make it unique
          .setLabel('👥 عرض المستخدمين')
          .setStyle(ButtonStyle.Secondary)
      );
    
    await interaction.editReply({
      embeds: [embed],
      components: [actionRow],
      ephemeral: true
    });
  } catch (error) {
    console.error('Error viewing system stats:', error);
    await interaction.editReply({
      content: 'حدث خطأ أثناء جلب إحصائيات النظام. يرجى المحاولة مرة أخرى.',
      ephemeral: true
    });
  }
}

// Function to force restart a bot
async function forceRestartBot(interaction, client, botId) {
  console.log(`[ADMIN ACTION] Force restart bot ${botId} - Admin ${interaction.user.tag} attempting to restart bot`);
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      console.log(`[ADMIN ACTION] Force restart bot ${botId} - Permission denied for ${interaction.user.tag}`);
      return interaction.editReply({
        content: 'ليس لديك صلاحية إعادة تشغيل البوتات.',
        ephemeral: true
      });
    }
    
    // Get bot from database
    const bot = await Bot.findOne({ botId });
    
    if (!bot) {
      console.log(`[ADMIN ACTION] Force restart bot ${botId} - Bot not found in database`);
      return interaction.editReply({
        content: 'لم يتم العثور على البوت. ربما تم حذفه بالفعل.',
        ephemeral: true
      });
    }
    
    console.log(`[ADMIN ACTION] Force restart bot ${botId} - Found bot: ${bot.name}`);
    
    // Check if bot is running
    const runningBot = client.runningBots.get(botId);
    if (!runningBot) {
      console.log(`[ADMIN ACTION] Force restart bot ${botId} - Bot is not currently running`);
      return interaction.editReply({
        content: `البوت ${bot.name} غير نشط حالياً. استخدم زر "تشغيل" بدلاً من ذلك.`,
        ephemeral: true
      });
    }
    
    // Append to log file
    fs.appendFileSync(
      bot.logPath,
      `\n[${new Date().toISOString()}] البوت تمت إعادة تشغيله قسرياً بواسطة المسؤول ${interaction.user.tag}\n`
    );
    console.log(`[ADMIN ACTION] Force restart bot ${botId} - Added restart info to bot's log file`);
    
    // Kill the process
    runningBot.process.kill();
    
    // Remove from running bots
    client.runningBots.delete(botId);
    
    // Increment restart counter
    client.botStats.totalRestarts++;
    
    // Update bot in database
    await Bot.findOneAndUpdate(
      { botId },
      { 
        $inc: { restarts: 1 },
        lastRestart: Date.now()
      },
      { new: true }
    );
    console.log(`[ADMIN ACTION] Force restart bot ${botId} - Bot updated in database, restarts incremented`);
    
    // Start the bot again
    // Decrypt token
    const CryptoJS = require('crypto-js');
    const decryptedToken = CryptoJS.AES.decrypt(bot.token, process.env.TOKEN).toString(CryptoJS.enc.Utf8);
    
    // Create .env file with bot token
    fs.writeFileSync(
      path.join(bot.path, '.env'),
      `TOKEN=${decryptedToken}`
    );
    
    // Create child process to run the bot
    const { spawn } = require('child_process');
    const botProcess = spawn('node', ['index.js'], { cwd: bot.path });
    
    // Add event listeners for the process
    botProcess.stdout.on('data', (data) => {
      fs.appendFileSync(bot.logPath, `[STDOUT] ${data}`);
    });
    
    botProcess.stderr.on('data', (data) => {
      fs.appendFileSync(bot.logPath, `[STDERR] ${data}`);
    });
    
    botProcess.on('close', (code) => {
      fs.appendFileSync(bot.logPath, `\n[${new Date().toISOString()}] Bot process exited with code ${code}\n`);
      client.runningBots.delete(botId);
      if (code !== 0) {
        client.botStats.crashedBots++;
      }
    });
    
    // Add to running bots map
    client.runningBots.set(botId, {
      botId,
      name: bot.name,
      owner: bot.owner,
      process: botProcess,
      startTime: Date.now()
    });
    
    // Send reply to user
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🔄 تمت إعادة تشغيل البوت')
          .setDescription(`تم إعادة تشغيل البوت **${bot.name}** بنجاح.`)
          .setColor('#2ecc71')
          .setTimestamp()
      ],
      ephemeral: true
    });
    
    // Log to channel if guild ID available
    if (interaction.guild) {
      await logBotRestart(bot, interaction.guild.id, interaction.user.tag, interaction.user.id, client);
      console.log(`[ADMIN ACTION] Force restart bot ${botId} - Log sent to log channel`);
    }
    
    console.log(`[ADMIN ACTION] Force restart bot ${botId} - Bot restarted successfully`);
  } catch (error) {
    console.error(`[ADMIN ACTION] Error force restarting bot ${botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء إعادة تشغيل البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to shutdown a bot
async function shutdownBot(interaction, client, botId) {
  console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Admin ${interaction.user.tag} attempting to shutdown bot`);
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Permission denied for ${interaction.user.tag}`);
      return interaction.editReply({
        content: 'ليس لديك صلاحية إيقاف البوتات.',
        ephemeral: true
      });
    }
    
    // Get bot from database
    const bot = await Bot.findOne({ botId });
    
    if (!bot) {
      console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Bot not found in database`);
      return interaction.editReply({
        content: 'لم يتم العثور على البوت. ربما تم حذفه بالفعل.',
        ephemeral: true
      });
    }
    
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Found bot: ${bot.name}`);
    
    // Check if bot is running
    const runningBot = client.runningBots.get(botId);
    if (!runningBot) {
      console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Bot is not currently running`);
      return interaction.editReply({
        content: `البوت ${bot.name} غير نشط حالياً. لا يمكن إيقافه.`,
        ephemeral: true
      });
    }
    
    // Append to log file
    fs.appendFileSync(
      bot.logPath,
      `\n[${new Date().toISOString()}] البوت تم إيقافه بواسطة المسؤول ${interaction.user.tag}\n`
    );
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Added shutdown info to bot's log file`);
    
    // Kill the process
    runningBot.process.kill();
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Process killed`);
    
    // Remove from running bots
    client.runningBots.delete(botId);
    client.botStats.botsRunning = client.runningBots.size;
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Removed from running bots. Updated botsRunning=${client.botStats.botsRunning}`);
    
    // Update bot in database
    await Bot.findOneAndUpdate(
      { botId },
      { 
        $set: { status: 'stopped' },
        lastShutdown: Date.now()
      },
      { new: true }
    );
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Bot status updated in database to 'stopped'`);
    
    // Send reply to user
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('⛔ تم إيقاف البوت')
          .setDescription(`تم إيقاف البوت **${bot.name}** بنجاح.`)
          .setColor('#e74c3c')
          .setTimestamp()
      ],
      ephemeral: true
    });
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Success message sent to admin`);
    
    // Log to channel if guild ID available
    if (interaction.guild) {
      await logBotShutdown(bot, interaction.guild.id, interaction.user.tag, interaction.user.id, client);
      console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Log sent to log channel`);
    }
    
    console.log(`[ADMIN ACTION] Shutdown bot ${botId} - Operation completed successfully`);
  } catch (error) {
    console.error(`[ADMIN ACTION] Error shutting down bot ${botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء إيقاف البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to unban a user
async function unbanUser(interaction, userId) {
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      return interaction.editReply({
        content: 'ليس لديك صلاحية إلغاء الحظر.',
        ephemeral: true
      });
    }
    
    // Get user from database
    const user = await User.findOne({ userId });
    
    if (!user) {
      return interaction.editReply({
        content: 'لم يتم العثور على المستخدم. ربما تم حذفه بالفعل.',
        ephemeral: true
      });
    }
    
    // Unban the user
    await User.findOneAndUpdate(
      { userId },
      { 
        $set: { isBanned: false, banReason: null },
        lastUnbanned: Date.now()
      },
      { new: true }
    );
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ تم إلغاء الحظر')
          .setDescription(`تم إلغاء الحظر على المستخدم **${user.username}** بنجاح.`)
          .setColor('#2ecc71')
          .setTimestamp()
      ],
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error unbanning user ${userId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء إلغاء الحظر: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to delete a bot
async function deleteBot(interaction, client, botId) {
  console.log(`[ADMIN ACTION] Delete bot ${botId} - Admin ${interaction.user.tag} (${interaction.user.id}) attempting to delete bot`);
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Permission denied for user ${interaction.user.tag} (${interaction.user.id})`);
      return interaction.editReply({
        content: 'ليس لديك صلاحية حذف البوتات.',
        ephemeral: true
      });
    }
    
    // Get bot from database
    const bot = await Bot.findOne({ botId });
    
    if (!bot) {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Bot not found in database`);
      return interaction.editReply({
        content: 'لم يتم العثور على البوت. ربما تم حذفه بالفعل.',
        ephemeral: true
      });
    }
    
    console.log(`[ADMIN ACTION] Delete bot ${botId} - Found bot: ${bot.name}, owned by ${bot.owner}`);
    
    // If bot is running, shut it down first
    if (client.runningBots.has(botId)) {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Shutting down running bot`);
      const runningBot = client.runningBots.get(botId);
      runningBot.process.kill();
      client.runningBots.delete(botId);
      client.botStats.botsRunning--;
    
      // Update unique users count
      const uniqueUsers = new Set([...client.runningBots.values()].map(b => b.owner));
      client.botStats.usersHosting = uniqueUsers.size;
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Bot shutdown complete. Updated stats: botsRunning=${client.botStats.botsRunning}, usersHosting=${client.botStats.usersHosting}`);
    }
    
    // Delete bot files if they exist
    if (fs.existsSync(bot.path)) {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Removing bot files from path: ${bot.path}`);
      fs.rmSync(bot.path, { recursive: true, force: true });
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Bot files removed successfully`);
    } else {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - No bot files found at path: ${bot.path}`);
    }
    
    // Delete bot from database
    console.log(`[ADMIN ACTION] Delete bot ${botId} - Deleting bot from database`);
    await Bot.findOneAndDelete({ botId });
    console.log(`[ADMIN ACTION] Delete bot ${botId} - Bot deleted from database successfully`);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🗑️ تم حذف البوت')
          .setDescription(`تم حذف البوت **${bot.name}** بنجاح.`)
          .setColor('#e74c3c')
          .setTimestamp()
      ],
      ephemeral: true
    });
    console.log(`[ADMIN ACTION] Delete bot ${botId} - Success message sent to admin`);
    
    // Send log to the log channel if guild ID is available
    if (interaction.guild) {
      await logBotDeletion(bot, interaction.guild.id, interaction.user.tag, interaction.user.id, client);
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Log sent to log channel`);
    }
    
    // Notify the owner
    const owner = await interaction.client.users.fetch(bot.owner).catch(() => null);
    if (owner) {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Attempting to notify owner ${bot.owner}`);
      owner.createDM().then(dmChannel => {
        dmChannel.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('🗑️ تم حذف البوت الخاص بك')
              .setDescription(`تم حذف البوت الخاص بك **${bot.name}** بواسطة أحد المشرفين.`)
              .setColor('#e74c3c')
              .setTimestamp()
          ]
        });
        console.log(`[ADMIN ACTION] Delete bot ${botId} - Notification sent to owner ${bot.owner}`);
      }).catch(err => console.error(`[ADMIN ACTION] Failed to send DM to owner ${bot.owner}:`, err));
    } else {
      console.log(`[ADMIN ACTION] Delete bot ${botId} - Could not fetch owner ${bot.owner} to send notification`);
    }
    
    console.log(`[ADMIN ACTION] Delete bot ${botId} - Operation completed successfully`);
  } catch (error) {
    console.error(`[ADMIN ACTION] Error deleting bot ${botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء حذف البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to delete a user
async function deleteUser(interaction, client, userId) {
  console.log(`[ADMIN ACTION] Delete user ${userId} - Admin ${interaction.user.tag} (${interaction.user.id}) attempting to delete user`);
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      console.log(`[ADMIN ACTION] Delete user ${userId} - Permission denied for ${interaction.user.tag} (${interaction.user.id})`);
      return interaction.editReply({
        content: 'ليس لديك صلاحية حذف المستخدمين.',
        ephemeral: true
      });
    }
    
    console.log(`[ADMIN ACTION] Delete user ${userId} - Admin permission verified for ${interaction.user.tag}`);
    
    // Get user from database
    const user = await User.findOne({ userId });
    
    if (!user) {
      console.log(`[ADMIN ACTION] Delete user ${userId} - User not found in database`);
      return interaction.editReply({
        content: 'لم يتم العثور على المستخدم. ربما تم حذفه بالفعل.',
        ephemeral: true
      });
    }
    
    console.log(`[ADMIN ACTION] Delete user ${userId} - User found: ${user.username}`);
    
    // Get all bots owned by this user
    const userBots = await Bot.find({ owner: userId });
    console.log(`[ADMIN ACTION] Delete user ${userId} - Found ${userBots.length} bots owned by this user`);
    
    // Shutdown and delete all bots owned by this user
    for (const bot of userBots) {
      console.log(`[ADMIN ACTION] Delete user ${userId} - Processing bot: ${bot.botId} (${bot.name})`);
      
      // If bot is running, shut it down
      if (client.runningBots.has(bot.botId)) {
        console.log(`[ADMIN ACTION] Delete user ${userId} - Shutting down running bot: ${bot.botId}`);
        const runningBot = client.runningBots.get(bot.botId);
        runningBot.process.kill();
        client.runningBots.delete(bot.botId);
        client.botStats.botsRunning--;
        console.log(`[ADMIN ACTION] Delete user ${userId} - Bot ${bot.botId} shutdown complete. Updated botsRunning=${client.botStats.botsRunning}`);
      }
      
      // Delete bot files
      if (fs.existsSync(bot.path)) {
        console.log(`[ADMIN ACTION] Delete user ${userId} - Removing files for bot ${bot.botId} at path: ${bot.path}`);
        fs.rmSync(bot.path, { recursive: true, force: true });
        console.log(`[ADMIN ACTION] Delete user ${userId} - Files removed for bot ${bot.botId}`);
      } else {
        console.log(`[ADMIN ACTION] Delete user ${userId} - No files found for bot ${bot.botId} at path: ${bot.path}`);
      }
    }
    
    // Delete all bots from database
    console.log(`[ADMIN ACTION] Delete user ${userId} - Deleting all user's bots from database`);
    await Bot.deleteMany({ owner: userId });
    console.log(`[ADMIN ACTION] Delete user ${userId} - All bots deleted from database`);
    
    // Delete user from database
    console.log(`[ADMIN ACTION] Delete user ${userId} - Deleting user from database`);
    await User.findOneAndDelete({ userId });
    console.log(`[ADMIN ACTION] Delete user ${userId} - User deleted from database`);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🗑️ تم حذف المستخدم')
          .setDescription(`تم حذف المستخدم **${user.username}** وجميع البوتات المرتبطة به بنجاح.`)
          .setColor('#e74c3c')
          .setTimestamp()
      ],
      ephemeral: true
    });
    console.log(`[ADMIN ACTION] Delete user ${userId} - Success message sent to admin`);
    
    // Send log to the log channel if guild ID is available
    if (interaction.guild) {
      await logUserDeletion(user, userBots.length, interaction.guild.id, interaction.user.tag, interaction.user.id, client);
      console.log(`[ADMIN ACTION] Delete user ${userId} - Log sent to log channel`);
    }
    
    // Try to notify the user
    console.log(`[ADMIN ACTION] Delete user ${userId} - Attempting to notify user`);
    try {
      const targetUser = await interaction.client.users.fetch(userId);
      if (targetUser) {
        await targetUser.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('🗑️ تم حذف حسابك')
              .setDescription('تم حذف حسابك وجميع البوتات المرتبطة به من خدمة استضافة البوتات.')
              .setColor('#e74c3c')
              .setTimestamp()
          ]
        });
        console.log(`[ADMIN ACTION] Delete user ${userId} - Notification sent to user successfully`);
      }
    } catch (dmError) {
      console.error(`[ADMIN ACTION] Delete user ${userId} - Could not send DM to user:`, dmError);
    }
    
    console.log(`[ADMIN ACTION] Delete user ${userId} - Operation completed successfully`);
  } catch (error) {
    console.error(`[ADMIN ACTION] Error deleting user ${userId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء حذف المستخدم: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to show ban user modal
async function showBanUserModal(interaction, userId) {
  try {
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const hasAdminRole = adminRoleIds.some(roleId => member.roles.cache.has(roleId));
    
    if (!hasAdminRole) {
      await interaction.reply({
        content: 'ليس لديك صلاحية حظر المستخدمين.',
        ephemeral: true
      });
      return;
    }
    
    // Create the modal
    const modal = new ModalBuilder()
      .setCustomId(`banUserModal:${userId}`)
      .setTitle('حظر المستخدم');
    
    // Create the text input component
    const banReasonInput = new TextInputBuilder()
      .setCustomId('banReason')
      .setLabel('سبب الحظر')
      .setPlaceholder('أدخل سبب الحظر هنا...')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMinLength(3)
      .setMaxLength(1000);
    
    // Create the action row
    const firstActionRow = new ActionRowBuilder().addComponents(banReasonInput);
    
    // Add the action row to the modal
    modal.addComponents(firstActionRow);
    
    // Show the modal
    await interaction.showModal(modal);
  } catch (error) {
    console.error(`Error showing ban user modal for ${userId}:`, error);
    await interaction.reply({
      content: 'حدث خطأ أثناء عرض نافذة الحظر. يرجى المحاولة مرة أخرى.',
      ephemeral: true
    });
  }
}

// Function to show give role modal
async function showGiveRoleModal(interaction, userId) {
  try {
    // Check if userId is valid
    if (!userId) {
      await interaction.reply({
        content: 'معرف المستخدم غير صالح.',
        ephemeral: true
      });
      return;
    }
    
    // Get user from database
    const user = await User.findOne({ userId });
    
    if (!user) {
      await interaction.reply({
        content: 'لم يتم العثور على المستخدم.',
        ephemeral: true
      });
      return;
    }
    
    // Create the modal
    const modal = new ModalBuilder()
      .setCustomId(`giveRoleModal:${userId}`)
      .setTitle('تعيين رتبة للمستخدم');
    
    // Create the select input component
    const roleInput = new TextInputBuilder()
      .setCustomId('roleType')
      .setLabel('نوع الرتبة')
      .setPlaceholder('free, premium, ultimate')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMinLength(3)
      .setMaxLength(10)
      .setValue(user.tier || 'free'); // Set current value
    
    // Create the action row
    const actionRow = new ActionRowBuilder().addComponents(roleInput);
    
    // Add the action row to the modal
    modal.addComponents(actionRow);
    
    // Show the modal
    await interaction.showModal(modal);
  } catch (error) {
    console.error(`Error showing give role modal for ${userId}:`, error);
    await interaction.reply({
      content: `حدث خطأ أثناء عرض نافذة تعيين الرتبة: ${error.message}`,
        ephemeral: true
      });
  }
}

// Handler for adminUserBots button
module.exports.executeOther = async function(interaction, client) {
  try {
    // Parse customId to get action and parameters
    const parts = interaction.customId.split(':');
    const handler = parts[0]; // adminUserBots
    const action = parts[1]; // view
    const userId = parts[2]; // userId
    const index = parts[3]; // index for uniqueness
    
    // Check if handler is valid
    if (handler !== 'adminUserBots') {
      return;
    }
    
    // Check if user has admin role
    const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
    const isAdmin = adminRoleIds.some(roleId => interaction.member.roles.cache.has(roleId));
    
    if (!isAdmin) {
      await interaction.reply({
        content: 'ليس لديك صلاحيات للوصول إلى لوحة الإدارة.',
      ephemeral: true
    });
      return;
    }
    
    await interaction.deferReply({ ephemeral: true });
    
    // Check if userId is defined
    if (!userId || userId === 'undefined') {
      return interaction.editReply({
        content: 'معرف المستخدم غير صالح أو غير محدد.',
        ephemeral: true
      });
    }
    
    if (action === 'view') {
      await viewUserBots(interaction, client, userId);
    } else {
      await interaction.editReply({
        content: 'إجراء غير صالح.',
        ephemeral: true
      });
    }
  } catch (error) {
    console.error(`Error handling adminUserBots action (${interaction.customId}):`, error);
    
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
        ephemeral: true
      });
    } else {
    await interaction.editReply({
        content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
      ephemeral: true
    });
  }
}
};

// Function to view user's bots
async function viewUserBots(interaction, client, userId) {
  try {
    // Make sure userId is valid
    if (!userId || userId === 'undefined') {
      console.error(`Invalid userId received: ${userId}`);
      return interaction.editReply({
        content: 'معرف المستخدم غير صالح. يرجى المحاولة مرة أخرى.',
        ephemeral: true
      });
    }
    
    // Get user from database
    const user = await User.findOne({ userId });
    
    if (!user) {
      return interaction.editReply({
        content: 'لم يتم العثور على المستخدم.',
        ephemeral: true
      });
    }
    
    // Get user's bots
    const userBots = await Bot.find({ owner: userId }).sort({ createdAt: -1 });
    
    if (userBots.length === 0) {
      return interaction.editReply({
        content: `المستخدم ${user.username} ليس لديه بوتات.`,
        ephemeral: true
      });
    }
    
    // Create embed
    const embed = new EmbedBuilder()
      .setTitle(`🤖 بوتات المستخدم ${user.username}`)
      .setDescription(`عدد البوتات: ${userBots.length}`)
      .setColor('#3498db')
      .setFooter({ text: `معرف المستخدم: ${userId}` });
    
    // Add fields for each bot
    for (const bot of userBots) {
      const isRunning = client.runningBots.has(bot.botId);
      
      embed.addFields({
        name: `${isRunning ? '🟢' : '🔴'} ${bot.name}`,
        value: `**المعرف:** ${bot.botId}\n**تاريخ الإنشاء:** <t:${Math.floor(bot.createdAt.getTime() / 1000)}:R>\n**الحالة:** ${isRunning ? 'قيد التشغيل' : bot.status === 'stopped' ? 'متوقف' : 'متعطل'}\n**إعادة التشغيل:** ${bot.restarts}`,
        inline: false
      });
    }
    
    // Create action buttons
    const components = [];
    
    // Add action buttons for each bot
    for (let i = 0; i < userBots.length; i++) {
      const bot = userBots[i];
      const isRunning = client.runningBots.has(bot.botId);
      
      const actionRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`adminAction:forceRestart:${bot.botId}:${i}`)
            .setLabel('🔧 إعادة تشغيل قسرية')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(!isRunning),
          new ButtonBuilder()
            .setCustomId(`adminAction:shutdownBot:${bot.botId}:${i}`)
            .setLabel('⛔ إيقاف')
            .setStyle(ButtonStyle.Danger)
            .setDisabled(!isRunning),
          new ButtonBuilder()
            .setCustomId(`adminAction:deleteBot:${bot.botId}:${i}`)
            .setLabel('🗑️ حذف البوت')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`botAction:logs:${bot.botId}:${i}`)
            .setLabel('📄 عرض السجلات')
            .setStyle(ButtonStyle.Secondary),
        );
      
      components.push(actionRow);
    }
    
    // Add back button
    const navigationRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`adminAction:viewUsers:${Date.now()}:back`)
          .setLabel('🔙 العودة إلى قائمة المستخدمين')
          .setStyle(ButtonStyle.Secondary)
      );
    
    components.push(navigationRow);
    
    await interaction.editReply({
      embeds: [embed],
      components: components,
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error viewing user bots for ${userId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء عرض بوتات المستخدم: ${error.message}`,
      ephemeral: true
    });
  }
}

// Utility function to format bytes to human-readable format
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Utility function to format uptime
function formatUptime(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  
  const parts = [];
  if (days > 0) parts.push(`${days} أيام`);
  if (hours > 0) parts.push(`${hours} ساعات`);
  if (minutes > 0) parts.push(`${minutes} دقائق`);
  if (seconds > 0) parts.push(`${seconds} ثوان`);
  
  return parts.join(', ');
}

// Function to get disk info
async function getDiskInfo() {
  try {
    const disk = require('diskusage');
    const path = '/';
    
    const info = await disk.check(path);
    
    return {
      free: info.free,
      total: info.total,
      used: info.total - info.free,
      usedPercentage: ((info.total - info.free) / info.total * 100).toFixed(2)
    };
  } catch (error) {
    console.error('Error getting disk info:', error);
    return {
      free: 0,
      total: 0,
      used: 0,
      usedPercentage: '0'
    };
  }
}

// Add this to be detected by the button handler system
module.exports.otherCustomIds = ['adminUserBots'];