const { SlashCommandBuilder, ChannelType, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const LogChannel = require('../database/models/LogChannel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogchannel')
    .setDescription('تعيين قناة لإرسال سجلات البوتات')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption(option =>
      option.setName('channel')
            .setDescription('قناة السجلات')
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)),
  
  async execute(interaction, client) {
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Check if user has admin permissions
      const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
      const isAdmin = adminRoleIds.some(roleId => interaction.member.roles.cache.has(roleId));
      
      if (!isAdmin && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.editReply({
          content: 'ليس لديك صلاحيات للوصول إلى أمر إعداد قناة السجلات.',
          ephemeral: true
        });
      }
      
      const channel = interaction.options.getChannel('channel');
      
      // Check if the bot has permissions to send messages in this channel
      const botMember = interaction.guild.members.me;
      if (!channel.permissionsFor(botMember).has('SendMessages')) {
        return interaction.editReply({
          content: 'لا يمكنني إرسال رسائل في هذه القناة. الرجاء منحي صلاحيات الكتابة أولًا.',
          ephemeral: true
        });
      }
      
      // Update or create log channel setting
      await LogChannel.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { 
          channelId: channel.id,
          updatedAt: Date.now()
        },
        { upsert: true, new: true }
      );
      
      // Send a test message to the channel
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setTitle('✅ تم تعيين قناة السجلات')
            .setDescription('سيتم إرسال سجلات البوتات إلى هذه القناة.')
            .setColor('#2ecc71')
            .setTimestamp()
        ]
      });
      
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('✅ تم تعيين قناة السجلات')
            .setDescription(`تم تعيين <#${channel.id}> كقناة للسجلات بنجاح.`)
            .setColor('#2ecc71')
            .setTimestamp()
        ]
      });
      
    } catch (error) {
      console.error('Error setting log channel:', error);
      await interaction.editReply({
        content: `حدث خطأ أثناء تعيين قناة السجلات: ${error.message}`,
        ephemeral: true
      });
    }
  }
}; 