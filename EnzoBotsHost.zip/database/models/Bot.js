const mongoose = require('mongoose');

const BotSchema = new mongoose.Schema({
  botId: {
    type: String,
    required: true,
    unique: true
  },
  name: {
    type: String,
    required: true
  },
  owner: {
    type: String,
    required: true
  },
  token: {
    type: String,
    required: true
  },
  path: {
    type: String,
    required: true
  },
  mainFile: {
    type: String,
    required: true
  },
  startTime: {
    type: Date,
    default: Date.now
  },
  logPath: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['running', 'stopped', 'crashed'],
    default: 'running'
  },
  restarts: {
    type: Number,
    default: 0
  },
  lastRestart: {
    type: Date,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Bot', BotSchema);
